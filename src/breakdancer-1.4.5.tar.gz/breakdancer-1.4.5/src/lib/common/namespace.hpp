#pragma once

#define BEGIN_NAMESPACE(x)  namespace x {
#define END_NAMESPACE(x)    }
