{% assign ubuntu_versions = "Ubuntu 10.04" %}
{% include install/download.html %}
{% include install/github.html %}
{% include install/help.html %}
